import os
import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cloud_resume_table')
allowed_origin = os.environ.get('ALLOWED_ORIGIN')

def lambda_handler(event, context):
    
    method = event.get("requestContext", {}).get("http", {}).get("method", "")
    
    headers = {
        "Access-Control-Allow-Origin": allowed_origin,
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }

    if method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": ""
        }

    if method == "GET":
        try:
            response = table.update_item(
                Key={'Id': 'resume_visits'},
                UpdateExpression='ADD #count :incr',
                ExpressionAttributeNames={'#count': 'count'},
                ExpressionAttributeValues={':incr': 1},
                ReturnValues='UPDATED_NEW'
            )
            new_count = response['Attributes']['count']
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'count': int(new_count)})
            }
        except ClientError as e:
            return {
                'statusCode': 500,
                'headers': headers,
                'body': json.dumps({'error': str(e)})
            }

    return {
        'statusCode': 405,
        'headers': headers,
        'body': json.dumps({'error': 'Method not allowed'})
    }
